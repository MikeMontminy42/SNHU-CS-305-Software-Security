package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController
class ServerController{
//FIXME:  Add hash function to return the checksum value for the data string that should contain your name. 
    private String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }	
    @RequestMapping("/hash")
    public String myHash(){
    	String data = "Hello Mike Montminy!";
    	String hashValue = "";
    	
    	try {
            // Creates a MessageDigest instance using SHA-256
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            // Generates the hash in byte format
            byte[] hash = digest.digest(data.getBytes());
            // Converts to a hex
            hashValue = bytesToHex(hash);
        } catch (NoSuchAlgorithmException e) {
            return "Error: " + e.getMessage();
        }
        
        return "<p>Data: " + data + "</p><p>Hash: " + hashValue + "</p>";
    }
}
