package com.snhu.sslserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SslServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
